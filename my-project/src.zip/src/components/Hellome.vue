<template>
  <div class="hellome">
    <h1>{{ msg }}</h1>
    <p v-text="title"></p>
    <input type="text" >
    <ul>
      <li v-for="(item, index) in items" v-bind:class = "{ finish: item.isFinished }" v-on:click = "doThis(item)">{{ index }} - {{ item.label }}</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'hellome',
  data () {
    return {
      msg: '欢迎来到magnet:?xt=urn:btih:',
      title: '这是一个备忘录，点击切换完成状态',
      items: [
      {label: '看视频', isFinished: false},
      {label: '写代码', isFinished: true},
      {label: '刷微博', isFinished: true},
      {label: '练画画', isFinished: false}]
    }
  },
  methods: {
    doThis: function (item) {
      item.isFinished = !item.isFinished
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  cursor: pointer;
  display: block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
.finish{ text-decoration: line-through; }
</style>
